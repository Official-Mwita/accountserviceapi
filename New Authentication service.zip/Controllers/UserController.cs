﻿using accountservice.Interfaces;
using accountservice.ServiceFactory;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace accountservice.Controllers
{
    //This controller manages authenticated user related endpoints such as get token, logout accounts, get account information
    //and many more
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _config;
        private ILogin? loginService;

        public UserController(IConfiguration config)
        {
            _config = config;
        }

        [HttpGet]
        [Route("get_userinfo")]
        public async Task<IActionResult> GetLoginInfo()
        {
            return Ok();
        }

        [HttpGet]
        [Route("logout")]
        public async Task<IActionResult> Logout()
        {
            if (User.Identity?.IsAuthenticated ?? false)
            {
                await HttpContext.SignOutAsync("auth_cookie");

                //Try to clear all existing

                return new OkObjectResult("Successful signed out");
            }

            return new UnauthorizedResult();

        }

        [HttpGet]
        [Route("access_token")]
        public string RefreshToken()
        {
            loginService = ServicesFactory.GetLoginService(HttpContext, _config, loginService);

            return loginService.GenerateUserToken();
        }
    }
}
